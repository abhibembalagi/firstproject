<?php
    $c=mysqli_connect('localhost','root','','doms') or die('Bad connections');
	$i = 0;
    	$s = "INSERT INTO `rollcall`(`rlno`,`usn`,`name`,`academicyear`,`division`,`semester`) values";
	for($i=0;$i<$_POST['number'];$i++)
	{
		$s .="('".$_POST['rol'][$i]."','".$_POST['usn'][$i]."','".$_POST['sname'][$i]."','".$_POST['ayear'][$i]."','".$_POST['adivision'][$i]."','".$_POST['asemester'][$i]."'),";
	}
	$s = rtrim($s,",");
	if(!mysqli_query($c, $s))
		echo"Records not inserted"; 	
	else
		echo"Records saved successfully"
		
?>