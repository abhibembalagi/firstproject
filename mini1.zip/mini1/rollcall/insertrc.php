<?php
$c=mysqli_connect('localhost','root','','doms');?>
<!DOCTYPE HTML>
<html>
<head><title>Subject allotment</title> 
</head>
<body><br/>
<form action="http://localhost/mini1/rollcall/insertrcq.php" method="POST">

<table align="center" border="1" cellspacing="9px 9px">
<tr>

<th colspan="3"><?php echo $_POST['division']; ?></th></tr>
<tr>
<th>ROLL CALL</th>
<th>USN</th>
<th>STUDENT NAME</th>

</tr>
<?php
$n=$_POST['stud'];

 for($i=1;$i<=$n;$i++){
	 ?>
<tr>
<td >
<input type="text" name="rol[]" value="<?php echo $i;?>"/>
</td>

<td>
<?php
$que1="select * from student";
$result1=mysqli_query($c,$que1);
echo "<select name='usn[]' >";
echo "<option >USN</option>";
while($row1=mysqli_fetch_array($result1)){
?>
<option><?php echo $row1['usn'];?></option>
<?php
}
echo"</select>"
?>
</td>
<td>
<?php
$que2="select * from student";
$result2=mysqli_query($c,$que2);
echo "<select name='sname[]' >";
echo "<option >STUDENT NAME</option>";
while($row2=mysqli_fetch_array($result2)){
?>
<option ><?php echo $row2['name'];?></option>
<?php
}
echo"</select>"
?>
</td>

<?php
$dateyear=$_POST['year'];
$divi=$_POST['division'];
$semester1=$_POST['semester'];

?>
<input type="hidden" name="ayear[]" value="<?php echo"$dateyear"?>">
<input type="hidden" name="asemester[]" value="<?php echo"$semester1"?>">
<input type="hidden" name="adivision[]" value="<?php echo"$divi"?>">
<?php
 }
 ?>
</table>
<br/>
<center>
<input type="hidden" name="number" value="<?php echo" $n"?>">
<input type="submit" value="Insert Data" name="insert" style="padding:6px;border:none;outline:none"/>
</form>
</center>

</body>
</html>