<?php
$syear=$_POST['year'];
$ssem=$_POST['semester'];
$division=$_POST['division'];

	   
		  
 require('C:\xampp\htdocs\mini1\fpdf18/fpdf.php');	

       $pdf=new FPDF();
	   $pdf->AddPage();
	   $con=mysqli_connect("localhost","root","","doms") or die("Bad connection");
 	   
	       
		   
		   $pdf->Image('C:\xampp\htdocs\mini1\images/logo.jpg',10,6,30);
		   $pdf->SetFont('Arial','B',15);
		   $pdf->Cell(100);
		   $pdf->Cell(30,10,'BASAVESHWAR ENGINEERING COLLEGE(AUTONOMOUS),',0,0,'C');
		   // Line break
           $pdf->Ln();
	       $pdf->Cell(103);
	       $pdf->SetFont('Arial','B',13);
	       $pdf->Cell(30,10,'DEPARTMENT OF INFORMATION SCIENCE ENGINEERING.',0,0,'C');
           $pdf->Ln();
		   $pdf->cell(60);
		   $pdf->Cell(64,10,'Academic Year:-'.$syear,0,0,'C');
		   $pdf->Cell(48,10,'Sem:-'.$ssem.' sem',0,0,'C');
           $pdf->Line(5, 45, 210-5, 45);
	       $pdf->Ln(18);
		   $pdf->Cell(70);
		   $pdf->Cell(48,10,$division,1,0,'C');
		   $pdf->Ln(18);
		   $pdf->Cell(48,10,'Roll No',1,0,'C');
		   $pdf->Cell(48,10,'USN',1,0,'C');
		   $pdf->Cell(48,10,'Student Name',1,0,'C');
		   $pdf->Cell(48,10,'Semester',1,0,'C');
		   $pdf->Ln();
		   
		   $stmt="SELECT * FROM `rollcall` where academicyear='$syear' and division='$division' and semester='$ssem' ";
		   
           $res=mysqli_query($con,$stmt);
		   while($row=mysqli_fetch_array($res)){
			   $pdf->Cell(48,10,$row['rlno'],1,0,'C');
			   $pdf->Cell(48,10,$row['usn'],1,0,'C');
			   $pdf->Cell(48,10,$row['name'],1,0,'C');
			   $pdf->Cell(48,10,$ssem,1,0,'C');
			   $pdf->Ln();
		   }
	
		   //removal
	 
	$pdf->output();	   		   

?>