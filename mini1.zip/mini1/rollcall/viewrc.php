<?php
$cn=mysqli_connect('localhost','root','','doms') or die('BAD SQL CONNECTION');
$c=$_POST['year'];
$d=$_POST['division'];
$e=$_POST['semester'];
?>
<html>
<body>
<center>
<table border="1">
<tr>
<th colspan="3"><?php echo $_POST['division']; ?></th></tr>
<tr>
<th>ROLL CALL</th>
<th>USN</th>
<th>STUDENT NAME</th>

</tr>
<?php
$query="select * from `rollcall` where academicyear='$c' and division='$d' and semester='$e'";

$result=mysqli_query($cn,$query);
	while($row=mysqli_fetch_assoc($result)){
		
?>
<tr><td><?php echo $row['rlno'];?></td>
<td><?php echo $row['usn'];?></td>
<td><?php echo $row['name'];?></td>


</tr>
<?php
}
?>
</table>
</center>
</body>
</html>