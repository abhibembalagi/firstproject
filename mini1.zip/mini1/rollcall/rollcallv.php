<html>
<head><style type="text/css">
</style></head>
<body>
<form action="http://localhost/mini1/rollcall/viewrc.php" method="POST">
<h2><p style="color:white;font-weight:bold"><u>SELECT ACADEMIC YEAR AND SEMESTER TO ALLOT SUBJECTS:-&nbsp </u></p></h2>
<table align="left">

<tr><td>

<label style="color:white;font-size:30px">
ACADEMIC YEAR:</td><td> <select name="year"></label>
<option>2015-2016</option>
<option>2016-2017</option>
<option>2017-2018</option>
<option>2018-2019</option>
<option>2019-2020</option>
</select>
</td></tr>

<tr>
<td>
<label style="color:white;font-size:28px">DIVISION:
</td>
<td><select name="division">
<option>A DIVISION</option>
<option>B DIVISION</option>
</select>
</td>
</tr>
<tr><td><label style="color:white;font-size:28px">SEMESTER:-</td><td><select name="semester">
<script>
for(var i=1;i<=8;i+=1)
{

document.write('<option value="'+i+'">'+i+'</option>');
}
</script>
</select></td></tr>

</table><br clear="all"/>
<br/><br/>
<button   style="text-decoration:none;color:white;font-size:24px;margin-left:50px;border:none;outline:none;padding:6px;border-radius:20px;background-color:green" target="_self">Submit</a>
</form>

 </body>
</html>