<?php
$con=mysqli_connect("localhost","root","","doms");
$year=$_POST['ayear'];
$sem=$_POST['asem'];
$type=$_POST['atype'];

if(isset($_POST['submit'])){
	
	$filename=addslashes($_FILES["img"]["name"]);
	$tmpname=addslashes(file_get_contents($_FILES["img"]["tmp_name"]));
    $filetype=addslashes($_FILES["img"]["type"]);
	$array=array('jpg','jpeg');
	$ext=pathinfo($filename,PATHINFO_EXTENSION);
	if(!empty($filename)){
		if(in_array($ext,$array)){
		$query="INSERT into `timetable`(name,image,academicyear,sem,type) values('$filename','$tmpname','$year','$sem','$type')";
		$result=mysqli_query($con,$query);
		if(!$result){
			echo"Image not uploaded please try again";
		}
		else{
			echo"Image uploaded successfully";
		}
		}
		else{
			echo"Unsupported image formart";
		}
	}
}
?>