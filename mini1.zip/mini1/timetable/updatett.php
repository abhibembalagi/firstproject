<?php
$year=$_POST['ayear'];
$sem=$_POST['asem'];
$type=$_POST['atype'];

?>

<html>
<body>
<form action="http://localhost/mini1/timetable/updatettq.php" enctype="multipart/form-data" method="post">
<input name="img" type="file" />
<input name="submit" type="submit" />
<input type="hidden" name="ayear" value="<?php echo "$year"?>">
<input type="hidden" name="asem" value="<?php echo "$sem"?>">
<input type="hidden" name="atype" value="<?php echo "$type"?>">
</form>
</body>
</html>