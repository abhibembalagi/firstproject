<?php

    $c=mysqli_connect('localhost','root','','doms') or die('Bad connections');
	$i = 0;
    	$s = "INSERT INTO `SUBJECTALLOTMENT`(`subjectcode`,`subjectname`,`faculty`,`credits`,`ayear`,`sem`) values";
	for($i=0;$i<$_POST['number'];$i++)
	{
		$s .="('".$_POST['subjectcode'][$i]."','".$_POST['subjectname'][$i]."','".$_POST['faculty'][$i]."','".$_POST['credits'][$i]."','".$_POST['ayear']."','".$_POST['asem']."'),";
	}
	$s = rtrim($s,",");
	if(!mysqli_query($c, $s))
		echo"Records not saved please try again!!!"; 	
	else
		echo"Records saved";
		
?>