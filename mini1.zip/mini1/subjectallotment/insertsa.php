<?php
$c=mysqli_connect('localhost','root','','doms');?>
<!DOCTYPE HTML>
<html>
<head><title>Subject allotment</title> 
</head>
<body><br/>
<form action="http://localhost/mini1/subjectallotment/insertsaq.php" method="POST">

<table align="center" border="1" cellspacing="9px 9px">
<tr>
<th>SUBJECT CODE</th>
<th>SUBJECT NAME</th>
<th>FACULTY NAME</th>
<th>CREDITS</th>

</tr>
<?php
$n=$_POST['number'];

 for($i=1;$i<=$n;$i++){
	 ?>
<tr>
<td>
<?php

$que="select * from academics";
$result=mysqli_query($c,$que);
echo "<select name='subjectcode[]'>";
echo "<option >SUBJECT CODE</option>";
while($row=mysqli_fetch_array($result)){
?>
<option ><?php echo $row['subcode'];?></option>
<?php
}
echo"</select>"
?>
</td>
<td>
<?php
$que1="select * from academics";
$result1=mysqli_query($c,$que1);
echo "<select name='subjectname[]' >";
echo "<option >SUBJECT NAME</option>";
while($row1=mysqli_fetch_array($result1)){
?>
<option><?php echo $row1['subname'];?></option>
<?php
}
echo"</select>"
?>
</td>
<td>
<?php
$que2="select * from faculty";
$result2=mysqli_query($c,$que2);
echo "<select name='faculty[]' >";
echo "<option >FACULTY NAME</option>";
while($row2=mysqli_fetch_array($result2)){
?>
<option ><?php echo $row2['faculty'];?></option>
<?php
}
echo"</select>"
?>
</td>
<td><select name="credits[]" >
<option>Credits</option>
<script>
for(var i=1;i<=5;i+=0.5	)
{

document.write('<option value="'+i+'">'+i+'</option>');
}
</script>
</td></tr>
<?php
 }
 ?>
</table>
<?php
$dateyear=$_POST['year'];
$sem1=$_POST['sem'];
?>
<input type="hidden" name="ayear" value="<?php echo"$dateyear"?>">
<input type="hidden" name="asem" value="<?php echo"$sem1"?>">



<br/>
<center>
<input type="hidden" name="number" value="<?php echo "$n"?>">
<input type="submit" value="Insert Data" name="insert" style="padding:6px;border:none;outline:none"/>
</form>
</center>

</body>
</html>