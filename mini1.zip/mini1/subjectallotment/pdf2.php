<?php
$syear=$_POST['year'];
$ssem=$_POST['sem'];
	   
		  
 require('C:\xampp\htdocs\mini1\fpdf18/fpdf.php');	

       $pdf=new FPDF();
	   $pdf->AddPage();
	   $con=mysqli_connect("localhost","root","","doms") or die("Bad connection");
 	   
	       
		   
		   $pdf->Image('C:\xampp\htdocs\mini1\images/logo.jpg',10,6,30);
		   $pdf->SetFont('Arial','B',15);
		   $pdf->Cell(100);
		   $pdf->Cell(30,10,'BASAVESHWAR ENGINEERING COLLEGE(AUTONOMOUS),',0,0,'C');
		   // Line break
           $pdf->Ln();
	       $pdf->Cell(103);
	       $pdf->SetFont('Arial','B',13);
	       $pdf->Cell(30,10,'DEPARTMENT OF INFORMATION SCIENCE ENGINEERING.',0,0,'C');
		   $pdf->Ln();
		   $pdf->cell(60);
		   $pdf->Cell(64,10,'Academic Year:-'.$syear,0,0,'C');
		   $pdf->Cell(48,10,'Sem:-'.$ssem,0,0,'C');
           $pdf->Line(5, 45, 210-5, 45);
	       
		  
		   
		   $pdf->Ln(20);
		   
		   $pdf->Cell(48,10,'Subject Code',1,0,'C');
		   $pdf->Cell(48,10,'Subject Name',1,0,'C');
		   $pdf->Cell(48,10,'Faculty Name',1,0,'C');
		   $pdf->Cell(48,10,'Credits',1,0,'C');
		   $pdf->Ln();
		   
		   $stmt="SELECT * FROM `subjectallotment` where ayear='$syear' and sem='$ssem'";
           $res=mysqli_query($con,$stmt);
		   while($row=mysqli_fetch_array($res)){
			   $pdf->Cell(48,10,$row['subjectcode'],1,0,'C');
			   $pdf->Cell(48,10,$row['subjectname'],1,0,'C');
			   $pdf->Cell(48,10,$row['faculty'],1,0,'C');
			   $pdf->Cell(48,10,$row['credits'],1,0,'C');
			   $pdf->Ln();
		   }
	
		   //removal
	 
	$pdf->output();	   		   

?>