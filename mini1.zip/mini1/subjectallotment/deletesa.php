<?php
$con=mysqli_connect('localhost','root','','doms');
$year1=$_POST['year'];
$sem1=$_POST['sem'];

?>
<html>
<body>
<form action="http://localhost/mini1/subjectallotment/deletesaq.php" method="POST">
<table align="center" border="1" cellspacing="9px 9px">
<tr>
<th>Subject Code:</th>
<td>
<?php
$year=$_POST['year'];
$que1="SELECT * FROM `subjectallotment` WHERE ayear='$year1' and sem='$sem1'";
$result=mysqli_query($con,$que1);
echo "<select name='subcode1'>";
echo "<option>Subject Code</option>";
while($row=mysqli_fetch_assoc($result)){
?>
<option><?php echo $row['subjectcode']; ?></option>
<?php
}
echo "</select>";
?>
</td>
</tr>

<tr>
<th>Subject Code:</th>
<td>
<?php
$que2="select * from `subjectallotment` where ayear='$year1' and sem='$sem1'";
$result1=mysqli_query($con,$que2);
echo "<select name='faculty1'>";
echo "<option>Faculty</option>";
while($row1=mysqli_fetch_assoc($result1)){
?>
<option><?php echo $row1['faculty']; ?></option>
<?php
}
echo "</select>";

?>
</td>
</tr>

<input type="hidden" name="year" value="<?php echo"$year1";?>">
<input type="hidden" name="sem" value="<?php echo"$sem1";?>">
</table>
<center>
<input type="submit" value="DELETE" style="padding:6px;border:none;outline:none"/>
</form>
</body>
</html>