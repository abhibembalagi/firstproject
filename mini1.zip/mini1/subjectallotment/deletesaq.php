<?php
    $cn=mysqli_connect('localhost','root','','doms') or die('Bad connections');
    $a=$_POST['subcode1'];
	$b=$_POST['faculty1'];
	
	$que="delete from `subjectallotment` where subjectcode='$a' and faculty='$b'";
	mysqli_query($cn,$que)

?>