<?php

    $c=mysqli_connect('localhost','root','','doms') or die('Bad connections');
	$i = 0;
    	$s = "INSERT INTO `counsellor`(`faculty`,`studentname`,`academicyear`,`usn`) values";
	for($i=0;$i<$_POST['n'];$i++)
	{
		$s .="('".$_POST['faculty']."','".$_POST['studentname'][$i]."','".$_POST['year']."','".$_POST['usn'][$i]."'),";
	}
	$s = rtrim($s,",");
	if(!mysqli_query($c, $s))
		echo"Records not saved please try again!!!"; 	
	else
		echo"Records saved";
		
?>