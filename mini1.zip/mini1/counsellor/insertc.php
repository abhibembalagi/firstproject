<?php
$c=mysqli_connect('localhost','root','','doms');
$year=$_POST['year'];
$faculty=$_POST['faculty'];
?>
<!DOCTYPE HTML>
<html>
<head><title>Subject allotment</title> 
</head>
<body><br/>
<form action="http://localhost/mini1/counsellor/insertcq.php" method="POST">

<table align="center" border="1" cellspacing="9px 9px">
<tr>
<th>STUDENT NAME</th>
<th>USN</th>
</tr>
<?php
$n=$_POST['n'];

 for($i=1;$i<=$n;$i++){
	 ?>
<tr>
<td>
<?php

$que="select * from student";
$result=mysqli_query($c,$que);
echo "<select name='studentname[]'>";
echo "<option >STUDENT NAME</option>";
while($row=mysqli_fetch_array($result)){
?>
<option ><?php echo $row['name'];?></option>
<?php
}
echo"</select>"
?>
</td>

<td>
<?php

$que="select * from student";
$result=mysqli_query($c,$que);
echo "<select name='usn[]'>";
echo "<option >STUDENT USN</option>";
while($row=mysqli_fetch_array($result)){
?>
<option ><?php echo $row['usn'];?></option>
<?php
}
echo"</select>"
?>
</td>
</tr>
<?php
 }
 ?>
 <input type="hidden" name="year" value="<?php echo "$year"?>"/>
 <input type="hidden" name="faculty" value="<?php echo "$faculty"?>"/>
 <input type="hidden" name="n" value="<?php echo "$n"?>"/>
 </table><center>
 <input type="submit" value="Insert Data"/></center>
 </form>
 </body>
 </html>