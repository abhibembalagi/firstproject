<!DOCTYPE html>
<html>
    <head>
        <style>
            
        </style>
    </head>
    <body>
        <?php
        # connect to mysql server
        # and select the database, on which
        # we will work.
        $conn = mysqli_connect('localhost', 'root', '','doms');
        
        $year=$_POST['year'];
		
        # Query the data from database.
        $query  = "SELECT * FROM `counsellor` where academicyear='$year'";
		
        $result = mysqli_query($conn,$query);

        
        $arr = array();
        $sal = array();
        $emp = array();

        while($row = mysqli_fetch_assoc($result)) {
            array_push($emp, $row['faculty']);
            array_push($sal, $row['studentname']);

            if (!isset($arr[$row['faculty']])) {
                $arr[$row['faculty']]['rowspan'] = 0;
            }
            $arr[$row['faculty']]['printed'] = 'no';
            $arr[$row['faculty']]['rowspan'] += 1;
        }

        echo "<center><table cellspacing='0' cellpadding='0' border='1'>
                <tr>
                    <th>Faculty</th>
                    <th>Student Name</th>
                </tr>";


        for($i=0; $i < sizeof($sal); $i++) {
            $empName = $emp[$i];
            echo "<tr>";

            # If this row is not printed then print.
            # and make the printed value to "yes", so that
            # next time it will not printed.
            if ($arr[$empName]['printed'] == 'no') {
                echo "<td rowspan='".$arr[$empName]['rowspan']."'>".$empName."</td>";
                $arr[$empName]['printed'] = 'yes';
            }
            echo "<td>".$sal[$i]."</td>";
            echo "</tr>";
        }
        echo "</table></center>";
        ?>
    </body>
</html>
