<html>
<head><style type="text/css">
</style></head>
<body>
<form action="http://localhost/mini1/counsellor/insertc.php" method="POST">
<h3><p style="color:white;font-weight:bold"><u>SELECT ACADEMIC YEAR AND SEMESTER TO UPDATE AND VIEW COUNSELLOR LIST:-&nbsp </u></p></h3>
<table align="left">

<tr><td>

<label style="color:white;font-size:30px">
ACADEMIC YEAR:</td><td> <select name="year"></label>
<option>2015-2016</option>
<option>2016-2017</option>
<option>2017-2018</option>
<option>2018-2019</option>
<option>2019-2020</option>
</select>
</td></tr>

<tr><td><label style="color:white;font-size:24px">
FACULTY NAME:</td>
<td>
<?php
$c=mysqli_connect('localhost','root','','doms');
$que2="select * from faculty";
$result2=mysqli_query($c,$que2);
echo "<select name='faculty' >";
echo "<option >FACULTY NAME</option>";
while($row2=mysqli_fetch_array($result2)){
?>
<option ><?php echo $row2['faculty'];?></option>
<?php
}
echo"</select>"
?>




<td>
</tr>
<tr><td><label style="color:white;font-size:24px">
NO OF STUDENTS:</td><td><input type="text" name="n"/></td></tr>
</table><br clear="all"/>
<center>
<button   style="float:left;text-decoration:none;color:white;font-size:24px;margin-left:0px;border:none;outline:none;padding:6px;border-radius:20px;background-color:green" target="_self">Submit</a>
</center>
</form>
 </body>
</html>