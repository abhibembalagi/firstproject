<?php
$connect=mysqli_connect("localhost","root","","doms") or die('Bad connection');
$username=$_POST['user'];
$password=$_POST['pwd'];
$query="select * from login where username='$username' and pwd='$password'";
$result=mysqli_query($connect,$query);
if($result->num_rows>0){
	while($row=$result->fetch_assoc()){
?>
	<script type="text/javascript">
window.location.href = 'admin.html';
</script>
<?php
}
}
else{
?>
	<script type="text/javascript">
window.location.href = 'login.html';
alert("username or password incorrect Please retry!!!");
</script>
<?php
}
?>