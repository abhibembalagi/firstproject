<html>
<body bgcolor="black">
<?php
$con=mysqli_connect("localhost","root","","doms");
$year=$_POST['ayear'];
$sem=$_POST['asem'];
$type=$_POST['atype'];

$query="SELECT * FROM `timetable` where academicyear='$year' and sem='$sem' and type='$type'";
$res=mysqli_query($con,$query);
while($row=mysqli_fetch_array($res)){
	echo '<center><br/><img src="data:image/jpeg;base64,'.base64_encode($row['image']).'"width="80%" height="90%"></center>';
}
?>
</body>
</html>