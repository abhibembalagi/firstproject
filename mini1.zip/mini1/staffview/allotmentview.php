<html>

    <head>
    <title>Students</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet"   href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://dunluce.infc.ulst.ac.uk/cw11ba/project/Project/mycss.css">

    </head>

    <form name="export_form" action="http://localhost/mini1/subjectallotment/pdf2.php" method="post">
    <input type="submit" name="submit_docs" value="Export as MS Word" class="input-button" />
    </form>

</html>