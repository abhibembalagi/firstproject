<?php
$c=mysqli_connect('localhost','root','','doms') or die('BAD SQL CONNECTION');
$year=$_POST['year'];
$sem=$_POST['sem'];
$query="SELECT * FROM `allotment` WHERE YEAR='$year' AND sem='$sem'";
$result=mysqli_query($c,$query);

?>
<html>
<body>
<center>
<form action="" method="GET">
<table border="1">
<tr><th>SL NO:</th>
<th>staff</th>
<th>Subject Code:</th>
<th>Subject Name:</th>
<th>Credits:</th>
<th>year:</th>
<th>sem:</th></tr>
<?php
	while($row=$result->fetch_assoc()){
?>
<tr><td><?php echo $row['slno'];?></td>
<td><?php echo $row['staff'];?></td>
<td><?php echo $row['subjectcode'];?></td>
<td><?php echo $row['subjectname'];?></td>
<td><?php echo $row['credits'];?></td>
<td><?php echo $row['year'];?></td>
<td><?php echo $row['sem'];?></td>

</tr>
<?php
}
?>
</table>
</form>
</center>
</body>
</html>