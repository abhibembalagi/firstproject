<!DOCTYPE html>
<html>
<title>ajay</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body, h1,h2,h3,h4,h5,h6 {font-family: "Montserrat", sans-serif}

/* Set the width of the sidebar to 120px */
.w3-sidebar {width: 120px;background: #222;}
/* Add a left margin to the "page content" that matches the width of the sidebar (120px) */
#main {margin-left: 120px}
/* Remove margins from "page content" on small screens */

</style>
<body class="w3-black">

<!-- Icon Bar (Sidebar - hidden on small screens) -->
<nav class="w3-sidebar w3-bar-block w3-small w3-hide-small w3-center">
  <!-- Avatar image in top left corner -->
  <img src="nature.jpg" style="width:100%">
  <a href="guest.html" class="w3-bar-item w3-button w3-padding-large w3-hover-black" >  <i class="fa fa-home w3-xxlarge"></i>
    <p> subject allotment</p>
  </a>
  <a href="workload.php" class="w3-bar-item w3-button w3-padding-large w3-hover-black">
    <i class="fa fa-eye w3-xxlarge"></i>
    <p>workload</p>
  </a>
  <a href="timetables.php" class="w3-bar-item w3-button w3-padding-large w3-hover-black">
    <i class="fa fa-window-restore w3-xxlarge"></i>
    <p>timetables</p>
  </a>
  <a href="rollcall.php" class="w3-bar-item w3-button w3-padding-large w3-black">
    <i class="fa fa-file-pdf-o w3-xxlarge"></i>
    <p>rollcall</p>
  </a>
  <a href="project.php" class="w3-bar-item w3-button w3-padding-large w3-hover-black">
    <i class="fa fa-users w3-xxlarge"></i>
    <p>projects groups</p>
  </a>
    <a href="counselor.php" class="w3-bar-item w3-button w3-padding-large w3-hover-black">
    <i class="fa fa-globe w3-xxlarge"></i>
    <p>counselor list</p>
  </a>
</nav>
<!-- Page Content -->
<div class="w3-padding-large" id="main">
  <!-- Header/Home -->
   
    <h1>DEPT OFFICE MGMT SYSTEM</h1>
	<h2 style="color:olive" >roll call</h2>
    
    <form action="http://localhost/mini1/rollcall/rollcallpdf.php" method="POST" >
<table border="1">
  <tr><th>year</th>
    <td> <select id="year" name="year">
<option>2015-2016</option>
<option>2016-2017</option>
<option>2017-2018</option>
<option>2018-2019</option>
<option>2019-2020</option>
</select></td></tr>
<tr><th>sem</th>
     <td><select name="semester" >
 <option>1</option>
 <option>2</option>
 <option>3</option>
 <option>4</option>
 <option>5</option>
 <option>6</option>
 <option>7</option>
 <option>8</option>
 
 </select></td></tr>
<tr><th>division</th><td><select name="division" >
 <option>A DIVISION</option>
 <option>B DIVISION</option>
 </select></td></tr>
      
     <tr> 
     <td colspan="2">  <center>  <button class="w3-button w3-light-grey w3-padding-medium" type="submit">
         <i class="fa fa-paper-plane"></i> VIEW 
        </button></center> 
      </td></tr>
</table>
    </form>

<!-- Contact Section -->
  <div class="w3-padding-64 w3-content w3-text-grey" id="contact">
    <h2 class="w3-text-light-grey">Contact Me</h2>
    <hr style="width:200px" class="w3-opacity">

    <div class="w3-section">
      <p><i class="fa fa-map-marker fa-fw w3-text-white w3-xxlarge w3-margin-right"></i>ise bgk</p>
      <p><i class="fa fa-phone fa-fw w3-text-white w3-xxlarge w3-margin-right"></i> Phone: 8951278070</p>
      <p><i class="fa fa-envelope fa-fw w3-text-white w3-xxlarge w3-margin-right"> </i> Email: ajayghale18l@gmail.com</p>
    </div>
  <!-- End Contact Section -->
  </div>
  
    <!-- Footer -->
  <footer class="w3-content w3-padding-64 w3-text-grey w3-xlarge">
    <i class="fa fa-facebook-official w3-hover-opacity"></i>
    <i class="fa fa-instagram w3-hover-opacity"></i>
    <i class="fa fa-snapchat w3-hover-opacity"></i>
    <i class="fa fa-pinterest-p w3-hover-opacity"></i>
    <i class="fa fa-twitter w3-hover-opacity"></i>
    <i class="fa fa-linkedin w3-hover-opacity"></i>
 
  <!-- End footer -->
  </footer>

<!-- END PAGE CONTENT -->
</div>

</body>
</html>